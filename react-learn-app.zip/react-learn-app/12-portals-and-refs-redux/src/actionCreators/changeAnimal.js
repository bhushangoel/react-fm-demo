export default function changeAnimal(animal) {
    return { type: "CHANGE_ANIMAL", payload: animal };
}