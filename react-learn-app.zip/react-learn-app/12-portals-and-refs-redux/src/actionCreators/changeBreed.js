export default function changeBreed(breed) {
    return { type: "CHANGE_BREED", payload: breed };
}