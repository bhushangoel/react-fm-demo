// root reducer: have the info about all other reducer functions
import { combineReducers } from "redux";
import location from "./location";
import animal from "./animal";
import theme from "./theme";
import breed from "./breed";

export default combineReducers({
    location,
    animal,
    theme,
    breed
})


// reducer is a giant object of things, where each function will handle
// a specific property. 
// example - location reducer handles location property

// {
//     location: "Seattle",
//     animal: "dog"
// }