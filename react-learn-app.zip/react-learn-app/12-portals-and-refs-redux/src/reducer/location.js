// reducer

export default function location(state="Seattle, WA", action) {
    switch (action.type) {
        case "CHANGE_LOCATION":
            return action.payload;
        default:
            return state;
    }
}

/*
format of action

{
    type: "CHANGE_LOCATION",
    payload: "Salt lake city, UT"   // OR
    payload: {
        state: "",
        city: ""
    }
}
*/